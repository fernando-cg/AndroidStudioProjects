package es.fesac.practica.ui.common

const val MIN_SQUARES = 3
const val MAX_SQUARES = 6