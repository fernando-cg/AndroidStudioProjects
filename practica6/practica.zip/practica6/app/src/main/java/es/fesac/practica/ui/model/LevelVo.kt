package es.fesac.practica.ui.model

import es.fesac.practica.ui.common.MIN_SQUARES

class LevelVo(val id: Long = -1, val title: String = "", val cellsNumber: Int = MIN_SQUARES, val record: Long)